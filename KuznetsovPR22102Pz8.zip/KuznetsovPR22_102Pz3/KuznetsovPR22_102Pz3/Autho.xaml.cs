﻿using KuznetsovPR22_102Pz3.Model;
using System;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;

namespace KuznetsovPR22_102Pz3
{
    public partial class Autho : Page
    {
        private int click;
        private int lockoutTime;
        private DispatcherTimer timer;
        public Autho()
        {
            InitializeComponent();
            click = 0;
            lockoutTime = 0;
            tbTimer.Foreground = new SolidColorBrush(Colors.Red);
            tbTimer.Visibility = Visibility.Hidden;

            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += Timer_Tick;
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            lockoutTime--;
            if (lockoutTime > 0)
            {
                tbTimer.Text = $"Окно разблокируется через {lockoutTime} секунд";
            }
            else
            {
                timer.Stop();
                UnlockControls();
            }
        }
        private void LockControls()
        {
            tbLogin.IsEnabled = false;
            tbPassword.IsEnabled = false;
            tbCaptcha.IsEnabled = false;
            btnEnter.IsEnabled = false;
            btnEnterGuest.IsEnabled = false;
            tbTimer.Visibility = Visibility.Visible;
        }
        private void UnlockControls()
        {
            tbLogin.IsEnabled = true;
            tbPassword.IsEnabled = true;
            tbCaptcha.IsEnabled = true;
            btnEnter.IsEnabled = true;
            btnEnterGuest.IsEnabled = true;
            tbTimer.Visibility = Visibility.Hidden;
            tbTimer.Text = string.Empty;
            click = 0;
        }
        public static string HashPassword(string password)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] sourceBytes = Encoding.UTF8.GetBytes(password);
                byte[] hashBytes = sha256Hash.ComputeHash(sourceBytes);
                return BitConverter.ToString(hashBytes).Replace("-", string.Empty);
            }
        }

        private void btnEnterGuest_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Client(null, null));
        }

        private void GenerateCapctcha()
        {
            tbCaptcha.Visibility = Visibility.Visible;
            tblCaptcha.Visibility = Visibility.Visible;

            string captchaText = CaptchaGenerator.GenerateCaptchaText(6);
            tblCaptcha.Text = captchaText;
            tblCaptcha.TextDecorations = TextDecorations.Strikethrough;
        }

        private void btnEnter_Click(object sender, RoutedEventArgs e)
        {
            if (!IsWithinWorkingHours())
            {
                MessageBox.Show("Доступ к системе возможен только в рабочие часы с 10:00 до 19:00.");
                return;
            }

            if (lockoutTime > 0)
            {
                MessageBox.Show("Окно заблокировано. Пожалуйста, подождите.");
                return;
            }

            click++;
            string login = tbLogin.Text.Trim();
            string password = HashPassword(tbPassword.Text.Trim());
            Furniture_centerEntities db = new Furniture_centerEntities();
            var user = db.Auth.Where(x => x.Username == login && x.Password == password).FirstOrDefault();

            if (click <= 3)
            {
                if (user != null)
                {
                    string greeting = GetUserGreeting(user);
                    MessageBox.Show(greeting);
                    LoadPage(user.RoleID.ToString(), user);
                }
                else
                {
                    MessageBox.Show("Вы ввели логин или пароль неверно!");
                    if (click == 3)
                    {
                        MessageBox.Show("Превышено количество попыток! Окно заблокировано на 10 секунд.");
                        LockControls();
                        lockoutTime = 10;
                        tbTimer.Text = $"Окно разблокируется через {lockoutTime} секунд";
                        timer.Start();
                    }
                    else
                    {
                        GenerateCapctcha();
                    }
                }
            }
        }
        private bool IsWithinWorkingHours()
        {
            TimeSpan currentTime = DateTime.Now.TimeOfDay;
            return currentTime >= TimeSpan.FromHours(10) && currentTime <= TimeSpan.FromHours(22);
        }
        private string GetTimeOfDayGreeting()
        {
            TimeSpan currentTime = DateTime.Now.TimeOfDay;

            if (currentTime >= TimeSpan.FromHours(10) && currentTime < TimeSpan.FromHours(12))
            {
                return "Доброе Утро";
            }
            else if (currentTime >= TimeSpan.FromHours(12) && currentTime < TimeSpan.FromHours(17))
            {
                return "Добрый День";
            }
            else if (currentTime >= TimeSpan.FromHours(17) && currentTime < TimeSpan.FromHours(19))
            {
                return "Добрый Вечер";
            }
            else
            {
                return "Сегодня уже не варик работать";
            }
        }
        private string GetUserGreeting(Auth user)
        {
            string fullName = "";

            using (var db = new Furniture_centerEntities())
            {
                if (user.RoleID == 1)
                {
                    var client = db.Clients.FirstOrDefault(x => x.AuthID == user.AuthID);
                    if (client != null)
                    {
                        fullName = $"{client.Surname} {client.Name} {client.MiddleName}";
                    }
                }
                else
                {
                    var employee = db.Employees.FirstOrDefault(x => x.AuthID == user.AuthID);
                    if (employee != null)
                    {
                        fullName = $"{employee.LastName} {employee.FirstName} {employee.MiddleName}";
                    }
                }
            }

            return $"{GetTimeOfDayGreeting()}! {fullName}";
        }

        private void LoadPage(string role, Auth user)
        {
            click = 0;
            tblCaptcha.Visibility = Visibility.Hidden;
            tbCaptcha.Clear();
            tbLogin.Clear();
            tbPassword.Clear();
            switch (role)
            {
                case "1":
                    NavigationService.Navigate(new Client(user, role));
                    break;
                case "2":
                    NavigationService.Navigate(new Buhgalter(user, role));
                    break;
                case "3":
                    NavigationService.Navigate(new Logist(user, role));
                    break;
                default:
                    MessageBox.Show("Роль не распознана!");
                    break;
            }
        }
    }
}